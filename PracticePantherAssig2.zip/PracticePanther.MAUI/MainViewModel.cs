﻿namespace PracticePanther.MAUI
{
    internal class MainViewModel
    {
        public MainViewModel()
        {
        }
    }
}