﻿using PracticePanther.CLI.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PracticePanther.Library.Services;
using PracticePanther.Library.Models;
using System.Xml.Linq;
using System.Windows.Input;

namespace PracticePanther.MAUI.ViewModels
{/*
    public class EditClientViewModel 
    {
        public Client Model { get; set; }

        public string Display
        {
            get
            {
                return Model.ToString() ?? string.Empty;
            }
        }

        public void Edit()
        {
            ClientService.Current.Edit(Model);
        }

    }*/

}
